import os

BINARIES_PATHS = [
    os.path.join(os.path.join(LOADER_DIR, '../../'), 'x64/vc14/bin')
] + BINARIES_PATHS
