from torch.nn.qat.dynamic.modules.linear import Linear


__all__ = ["Linear"]
