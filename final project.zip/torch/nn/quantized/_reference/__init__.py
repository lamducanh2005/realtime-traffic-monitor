from torch.nn.quantized._reference.modules import *  # noqa: F403
