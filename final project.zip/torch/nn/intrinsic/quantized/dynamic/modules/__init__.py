from torch.nn.intrinsic.quantized.dynamic.modules.linear_relu import LinearReLU


__all__ = [
    "LinearReLU",
]
