from torch.nn.intrinsic.qat.modules import *  # noqa: F403
