# mypy: allow-untyped-defs
# this is for historical pickle deserialization, it is not used otherwise


def _get_thnn_function_backend():
    pass
