from .type_promotion import InsertTypePromotion


__all__ = [
    "InsertTypePromotion",
]
